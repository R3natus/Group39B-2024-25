// index.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const db = require('./database');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Root route handler for "/"
app.get('/', (req, res) => {
  res.send('Welcome to the To-Do List App API!');
});

// Register and login endpoints...
app.post('/api/register', async (req, res) => {
  const { email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  
  db.run('INSERT INTO users (email, password) VALUES (?, ?)', [email, hashedPassword], function (err) {
    if (err) {
      return res.status(500).send({ error: 'User registration failed' });
    }
    res.status(201).send({ message: 'User registered successfully', userId: this.lastID });
  });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;

  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) return res.status(500).send({ error: 'Database error' });
    if (!user) return res.status(401).send({ error: 'Invalid email or password' });

    const isPasswordMatch = await bcrypt.compare(password, user.password);
    if (!isPasswordMatch) return res.status(401).send({ error: 'Invalid email or password' });

    res.send({ message: 'Logged in successfully', userId: user.id });
  });
});

// Task endpoints...

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});