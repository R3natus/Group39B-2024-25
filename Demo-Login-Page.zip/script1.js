document.addEventListener("DOMContentLoaded", function() {
    const wrapper = document.querySelector('.wrapper1');
    const loginLink = document.querySelector('.login-link');
    const registerLink = document.querySelector('.register-link');

    // Toggle between login and register forms
    if (registerLink && loginLink && wrapper) {
        registerLink.addEventListener('click', () => {
            wrapper.classList.add('active');
        });

        loginLink.addEventListener('click', () => {
            wrapper.classList.remove('active');
        });
    }
});

function validatePasswords() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const passwordError = document.getElementById('passwordError');

    if (password !== confirmPassword) {
        passwordError.style.display = 'block'; // Show the error message
        return false; // Prevent form submission
    } else {
        passwordError.style.display = 'none'; // Hide the error message
        return true; // Allow form submission
    }
}


// Register user
async function registerUser(email, password) {
    try {
      const response = await fetch('http://localhost:3000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (response.ok) {
        alert(data.message); // Success alert
      } else {
        alert(data.error); // Error alert
      }
    } catch (error) {
      console.error('Registration error:', error);
    }
  }
  
  // Login user
  async function loginUser(email, password) {
    try {
      const response = await fetch('http://localhost:3000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (response.ok) {
        alert(data.message); // Success alert
      } else {
        alert(data.error); // Error alert
      }
    } catch (error) {
      console.error('Login error:', error);
    }
  }
  
  // Event listeners for form submission
  document.getElementById('registerForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.querySelector('#registerForm input[type="email"]').value;
    const password = document.querySelector('#registerForm input#password').value;
    registerUser(email, password);
  });
  
  document.querySelector('.login .btn').addEventListener('click', (e) => {
    e.preventDefault();
    const email = document.querySelector('.login input[type="email"]').value;
    const password = document.querySelector('.login input[type="password"]').value;
    loginUser(email, password);
  });

  